import FieldReport from './field-report';
import {headers} from 'next/headers';
import {isAdmin} from './access';
export const dynamic='force-dynamic';
export default async function Home(){const h=await headers();const admin=await isAdmin(new Request('https://local/',{headers:{cookie:h.get('cookie')||''}}));return admin?<FieldReport/>:<div className="public-landing"><span className="landing-leaf">◒</span><p className="eyebrow">INFORME DE CAMPO</p><h1>Cinco años.<br/><em>Tu historia cuenta.</em></h1><p>Completa tu información, comparte tus experiencias y añade fotos de tu trabajo.</p><section><h2>Abre tu enlace personal</h2><p>La persona que organiza el informe te enviará un enlace por WhatsApp. Con ese enlace podrás completar tus datos y volver para actualizarlos.</p></section><small>Si organizas el informe, utiliza tu enlace de administración.</small></div>;}

