import {env} from 'cloudflare:workers';
import {participantAccess,noAccess,sameOrigin} from '../../../access';
import {initialData,newAnnual,hasAnnual,normalizeData} from '../../../model';
async function read(){const row=await env.DB!.prepare('SELECT payload,version FROM reports WHERE id = ?').bind('main').first<{payload:string;version:number}>();return row?{data:normalizeData(JSON.parse(row.payload)),version:row.version}:{data:initialData(),version:0};}
export async function GET(req:Request,{params}:{params:Promise<{id:string}>}){const {id}=await params;if(await participantAccess(req)!==id)return noAccess();const {data}=await read();const person=data.people.find((p:any)=>p.id===id);if(!person)return noAccess();return Response.json({title:data.title,startYear:data.startYear,person,annual:Array.from({length:5},(_,i)=>data.annual.find((a:any)=>a.personId===id&&a.year===i+1)||newAnnual(id,i+1)),photos:data.photos.filter((p:any)=>p.personId===id),version:data.personVersions?.[id]||0},{headers:{'Cache-Control':'no-store'}});}
export async function PUT(req:Request,{params}:{params:Promise<{id:string}>}){
 const {id}=await params;if(!sameOrigin(req)||await participantAccess(req)!==id)return noAccess();
 try{
 const raw=await req.text();if(raw.length>1000000)return Response.json({error:'La información es demasiado extensa.'},{status:413});const input=JSON.parse(raw);
 const text=(v:any,n=30000)=>typeof v==='string'&&v.length<=n;
 if(!input.person||!Array.isArray(input.annual)||input.annual.length!==5||!Array.isArray(input.photos)||input.photos.length>300||!Number.isInteger(input.version))return Response.json({error:'Revisa la información del formulario.'},{status:400});
 const fields=['name','role','location','bio','summary','fundingLabel','fundingUrl','fundingImageId'];const profile:any={};for(const f of fields){const v=input.person[f]??'';if(!text(v))return Response.json({error:'Revisa los datos personales.'},{status:400});profile[f]=v;}
 if(profile.fundingUrl&&!/^https?:\/\//i.test(profile.fundingUrl))return Response.json({error:'El enlace de donaciones debe comenzar con https://.'},{status:400});
 if(profile.fundingImageId){const obj=await env.BUCKET!.head(profile.fundingImageId);if(!obj||obj.customMetadata?.personId!==id)return noAccess();}
 const annual=[];const seen=new Set();for(const a of input.annual){if(!Number.isInteger(a.year)||a.year<1||a.year>5||seen.has(a.year))return Response.json({error:'Revisa los cinco años del informe.'},{status:400});seen.add(a.year);const next:any={personId:id,year:a.year,status:a.status==="No corresponde"?"No corresponde":"En proceso"};for(const f of ['activities','results','measure','value','units','story','challenges','lessons','source']){if(!text(a[f]))return Response.json({error:'Revisa los datos anuales.'},{status:400});next[f]=a[f];}annual.push(next);}
 const photos=[];const photoIds=new Set();for(const p of input.photos){if(!text(p.id,100)||photoIds.has(p.id)||!Number.isInteger(p.year)||p.year<1||p.year>5)return Response.json({error:'Revisa los datos de las fotos.'},{status:400});photoIds.add(p.id);const next:any={id:p.id,personId:id,year:p.year};for(const f of ['imageId','externalUrl','filename','caption','date','location','credit','permission']){if(!text(p[f]))return Response.json({error:'Revisa las fotos.'},{status:400});next[f]=p[f];}if(!["Pendiente","Confirmado","No utilizar"].includes(p.permission)||p.externalUrl&&!/^https?:\/\//i.test(p.externalUrl))return Response.json({error:'Revisa los enlaces y permisos de las fotos.'},{status:400});if(p.imageId){const obj=await env.BUCKET!.head(p.imageId);if(!obj||obj.customMetadata?.personId!==id)return noAccess();}photos.push(next);}
 if(input.submit&&(!profile.name.trim()||annual.some(a=>a.status!=="No corresponde"&&!hasAnnual(a))))return Response.json({error:'Añade tu nombre y completa los cinco años. Si no participaste en un año, marca «No corresponde».'},{status:400});
 for(let attempt=0;attempt<5;attempt++){
  const {data,version}=await read();const p=data.people.find((p:any)=>p.id===id);if(!p)return noAccess();
  if((data.personVersions?.[id]||0)!==input.version)return Response.json({error:'Tus datos cambiaron en otra ventana o durante la revisión. Recarga antes de guardar. El texto que estás editando sigue en este formulario.'},{status:409});
  if(photos.some(photo=>data.photos.some((existing:any)=>existing.id===photo.id&&existing.personId!==id)))return noAccess();
  data.people=data.people.map((p:any)=>p.id===id?{...p,...profile,informationStatus:input.submit?"Enviado para revisión":"En proceso",photoStatus:photos.length?'En proceso':'Sin empezar',reportStatus:p.reportStatus==="Completo"?"Requiere seguimiento":p.reportStatus}:p);
  data.annual=[...data.annual.filter((a:any)=>a.personId!==id),...annual.map(a=>({...a,status:a.status==="No corresponde"?"No corresponde":input.submit?"Enviado para revisión":a.status}))];
  data.photos=[...data.photos.filter((p:any)=>p.personId!==id),...photos];data.personVersions={...data.personVersions,[id]:input.version+1};
  const now=new Date().toISOString();const result=version===0?await env.DB!.prepare('INSERT INTO reports (id,payload,version,updated_at) VALUES (?,?,1,?) ON CONFLICT(id) DO NOTHING').bind('main',JSON.stringify(data),now).run():await env.DB!.prepare('UPDATE reports SET payload = ?, version = ?, updated_at = ? WHERE id = ? AND version = ?').bind(JSON.stringify(data),version+1,now,'main',version).run();
  if(result.meta.changes)return Response.json({version:input.version+1,status:input.submit?"Enviado para revisión":"En proceso",savedAt:now},{headers:{'Cache-Control':'no-store'}});
 }
 return Response.json({error:'Hay varias personas guardando. Inténtalo de nuevo en unos segundos.'},{status:409});
 }catch(e){console.error('Participant save failed',e);return Response.json({error:'No se pudieron guardar tus datos. Inténtalo de nuevo.'},{status:500});}
}

