import type { Metadata } from "next";
import "./globals.css";
import "./participant.css";
import "./demo.css";

export const metadata: Metadata = {
  title: "Informe de campo — Cinco años, un solo lugar",
  description: "Reúne historias, resultados y fotografías de cinco años. Exporta la información para Excel.",
  referrer: "no-referrer",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}
