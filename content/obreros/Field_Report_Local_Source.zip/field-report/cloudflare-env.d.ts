declare namespace Cloudflare {
  interface Env {
    REPORT_SECRET?: string;
    DB?: D1Database;
    BUCKET?: R2Bucket;
  }
}
